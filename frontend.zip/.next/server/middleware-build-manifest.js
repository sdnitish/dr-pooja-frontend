globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/6968ad670bd1d5cf.js",
      "static/chunks/turbopack-80d5d950508a0d3b.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/6968ad670bd1d5cf.js",
      "static/chunks/turbopack-de0348dcb27d01c1.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/cc7a37a4d13e820f.js",
    "static/chunks/e6b0468bc5e7fb2f.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/7fd964e6e7d66713.js",
    "static/chunks/674649e7dad9f6b4.js",
    "static/chunks/turbopack-7197bf673cbf1394.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];