module.exports=[53787,a=>{a.v("/_next/static/media/favicon.12586d24.ico")},47290,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(53787).default,width:48,height:48}}];

//# sourceMappingURL=app_0ef037c1._.js.map