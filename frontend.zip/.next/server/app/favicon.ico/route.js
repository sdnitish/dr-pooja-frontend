var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__846173bf._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_a3034f85._.js")
R.m(13870)
R.m(17951)
module.exports=R.m(17951).exports
