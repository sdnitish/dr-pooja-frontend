var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/website/settings/route.js")
R.c("server/chunks/[root-of-the-server]__573caf82._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_b789cbd3._.js")
R.m(76557)
R.m(18306)
module.exports=R.m(18306).exports
