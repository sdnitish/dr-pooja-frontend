var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__006aab9c._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.m(79543)
R.m(75966)
module.exports=R.m(75966).exports
