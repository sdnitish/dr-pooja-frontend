var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__75f4cc02._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_b789cbd3._.js")
R.m(9606)
R.m(98326)
module.exports=R.m(98326).exports
