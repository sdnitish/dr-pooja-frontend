var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/front/blog/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__813b13ae._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.m(24253)
R.m(83751)
module.exports=R.m(83751).exports
