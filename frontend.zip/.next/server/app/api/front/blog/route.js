var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/front/blog/route.js")
R.c("server/chunks/[root-of-the-server]__f9a65ff2._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.m(18059)
R.m(49223)
module.exports=R.m(49223).exports
