var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/front/service/route.js")
R.c("server/chunks/[root-of-the-server]__062c713a._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.m(15934)
R.m(38971)
module.exports=R.m(38971).exports
