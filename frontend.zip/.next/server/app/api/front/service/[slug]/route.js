var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/front/service/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__e7fd522b._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.m(88534)
R.m(11882)
module.exports=R.m(11882).exports
