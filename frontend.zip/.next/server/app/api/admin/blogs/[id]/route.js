var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/blogs/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__9f8c61b1._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_b789cbd3._.js")
R.m(48532)
R.m(65932)
module.exports=R.m(65932).exports
