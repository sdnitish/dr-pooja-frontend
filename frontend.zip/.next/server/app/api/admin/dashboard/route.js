var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__19cc7cda._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_b789cbd3._.js")
R.m(22284)
R.m(53923)
module.exports=R.m(53923).exports
