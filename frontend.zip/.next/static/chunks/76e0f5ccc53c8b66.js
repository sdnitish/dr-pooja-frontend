__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/6968ad670bd1d5cf.js",
  "static/chunks/turbopack-80d5d950508a0d3b.js"
])
