__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/6968ad670bd1d5cf.js",
  "static/chunks/turbopack-de0348dcb27d01c1.js"
])
