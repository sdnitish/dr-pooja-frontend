import React from 'react'

const Hero = () => {
  return (
    <div>
        <img className='w-full' src="/img/banner-1.jpeg" alt="Banner" />
    </div>
  )
}

export default Hero