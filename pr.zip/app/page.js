import Image from "next/image";
import Hero from "./components/sections/Hero";
import HomeAbout from "./components/sections/HomeAbout";
import Services from "./components/sections/Services";
import Clients from "./components/sections/Clients";
import YouTube from "./components/sections/YouTube";

export default function Home() {
  return (
    <>
      <Hero />
      <HomeAbout />
      <Services />
      <Clients />
      <YouTube />
    </>
  );
}
