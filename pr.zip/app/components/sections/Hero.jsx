import React from 'react'

const Hero = () => {
  return (
    <div>
        <img className='w-full' src="/img/banner1.png" alt="Banner" />
    </div>
  )
}

export default Hero