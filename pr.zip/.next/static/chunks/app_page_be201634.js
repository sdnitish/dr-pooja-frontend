(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1c517992._.js",
  "static/chunks/app_components_0cf8ddea._.js",
  "static/chunks/node_modules_swiper_d1c3e0cc._.css"
],
    source: "dynamic"
});
